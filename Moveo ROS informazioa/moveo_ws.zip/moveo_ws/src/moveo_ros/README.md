Still working on stuff, but this is a repo for the ROS packages, for my bcn3d moveo robot.

To run the sim in Gazebo: roslaunch moveo_moveit_config demo.launch